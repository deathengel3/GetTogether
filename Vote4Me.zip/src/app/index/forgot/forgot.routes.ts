import { Route } from '@angular/router';
import { ForgotComponent } from "./forgot.component";

export const ForgotRoutes: Route[] = [
    {
        path: '',
        component: ForgotComponent
    }
];