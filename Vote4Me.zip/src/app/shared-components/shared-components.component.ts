import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shared-components',
  templateUrl: './shared-components.component.html',
  styleUrls: ['./shared-components.component.scss']
})
export class SharedComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
