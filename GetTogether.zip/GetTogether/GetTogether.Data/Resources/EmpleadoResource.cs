﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace GetTogether.Data.Resources
{
    public class EmpleadoResource
    {
        public string NumeroEmpleado { get; set; }
        public string Nombre { get; set; }
    }
}
