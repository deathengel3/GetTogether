﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GetTogether.Data.Models
{
    public class Error
    {
        public int EstatusHttp { get; set; }
        public string MensajeError { get; set; }
    }
}
